<?php
declare(strict_types=1);

require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/includes/helpers.php';

header('Content-Type: application/json; charset=utf-8');

$action = str($_GET['action'] ?? '');
$method = strtoupper($_SERVER['REQUEST_METHOD']);

try {
    match ($action) {
        'login'    => handleLogin(),
        'register' => handleRegister(),
        'logout'   => handleLogout(),
        'me'       => handleMe(),
        'lists'    => handleLists($method),
        'tasks'    => handleTasks($method),
        'subtasks' => handleSubtasks($method),
        default    => json(['error' => 'Unknown action'], 404),
    };
} catch (\Throwable $e) {
    json(['error' => $e->getMessage()], 500);
}

// ── AUTH ───────────────────────────────────────────────────────────────────

function handleLogin(): never {
    $b = body();
    $user = login(str($b['email'] ?? ''), str($b['password'] ?? ''));
    if (!$user) {
        json(['error' => 'Invalid email or password.'], 401);
    }
    unset($user['password']);
    json(['user' => $user]);
}

function handleRegister(): never {
    $b    = body();
    $result = register(str($b['name'] ?? ''), str($b['email'] ?? ''), str($b['password'] ?? ''));
    if (is_string($result)) {
        json(['error' => $result], 422);
    }
    unset($result['password']);
    json(['user' => $result], 201);
}

function handleLogout(): never {
    doLogout();
    json(['ok' => true]);
}

function handleMe(): never {
    $uid  = requireAuth();
    $user = dbRow('SELECT id, name, email, theme, created_at FROM users WHERE id = ?', [$uid]);
    json(['user' => $user]);
}

// ── LISTS ──────────────────────────────────────────────────────────────────

function handleLists(string $method): never {
    $uid = requireAuth();
    $id  = isset($_GET['id']) ? intval_safe($_GET['id']) : null;

    match ($method) {
        'GET' => (function () use ($uid) {
            $lists = dbRows(
                'SELECT * FROM lists WHERE user_id = ? ORDER BY is_default DESC, sort_order ASC, id ASC',
                [$uid]
            );
            // Attach task counts
            foreach ($lists as &$list) {
                $list['task_count'] = dbCount(
                    'SELECT COUNT(*) FROM tasks WHERE list_id = ? AND is_completed = 0',
                    [$list['id']]
                );
            }
            unset($list);
            json(['lists' => $lists]);
        })(),

        'POST' => (function () use ($uid) {
            $b    = body();
            $name = str($b['name'] ?? '');
            if (!$name) json(['error' => 'Name is required'], 422);
            $icon  = str($b['icon']  ?? '📋');
            $color = str($b['color'] ?? '#2564CF');
            $id    = dbExecute(
                'INSERT INTO lists (user_id, name, icon, color) VALUES (?, ?, ?, ?)',
                [$uid, $name, $icon, $color]
            );
            json(['list' => dbRow('SELECT * FROM lists WHERE id = ?', [$id])], 201);
        })(),

        'PUT' => (function () use ($uid, $id) {
            if (!$id) json(['error' => 'List ID required'], 422);
            $list = dbRow('SELECT * FROM lists WHERE id = ? AND user_id = ?', [$id, $uid]);
            if (!$list) json(['error' => 'Not found'], 404);
            $b    = body();
            $name  = str($b['name']  ?? $list['name']);
            $icon  = str($b['icon']  ?? $list['icon']);
            $color = str($b['color'] ?? $list['color']);
            dbExecute(
                'UPDATE lists SET name = ?, icon = ?, color = ? WHERE id = ? AND user_id = ?',
                [$name, $icon, $color, $id, $uid]
            );
            json(['list' => dbRow('SELECT * FROM lists WHERE id = ?', [$id])]);
        })(),

        'DELETE' => (function () use ($uid, $id) {
            if (!$id) json(['error' => 'List ID required'], 422);
            $list = dbRow('SELECT * FROM lists WHERE id = ? AND user_id = ?', [$id, $uid]);
            if (!$list) json(['error' => 'Not found'], 404);
            if ($list['is_default']) json(['error' => 'Cannot delete default list'], 422);
            dbExecute('DELETE FROM lists WHERE id = ? AND user_id = ?', [$id, $uid]);
            json(['ok' => true]);
        })(),

        default => json(['error' => 'Method not allowed'], 405),
    };
}

// ── TASKS ──────────────────────────────────────────────────────────────────

function handleTasks(string $method): never {
    $uid    = requireAuth();
    $id     = isset($_GET['id'])      ? intval_safe($_GET['id'])      : null;
    $listId = isset($_GET['list_id']) ? intval_safe($_GET['list_id']) : null;
    $filter = str($_GET['filter'] ?? 'all');

    match ($method) {
        'GET' => (function () use ($uid, $listId, $filter) {
            $today = date('Y-m-d');
            [$where, $params] = match ($filter) {
                'my_day'    => ['AND t.is_my_day = 1', []],
                'important' => ['AND t.is_starred = 1', []],
                'planned'   => ['AND t.due_date IS NOT NULL', []],
                'completed' => ['AND t.is_completed = 1', []],
                'list'      => ['AND t.list_id = ?', [$listId]],
                default     => ['', []],
            };
            $sql = "SELECT t.*, l.name as list_name, l.color as list_color
                    FROM tasks t
                    LEFT JOIN lists l ON l.id = t.list_id
                    WHERE t.user_id = ? $where
                    ORDER BY t.is_completed ASC, t.is_starred DESC, t.sort_order ASC, t.id DESC";
            $tasks = dbRows($sql, array_merge([$uid], $params));
            json(['tasks' => $tasks]);
        })(),

        'POST' => (function () use ($uid) {
            $b     = body();
            $title = str($b['title'] ?? '');
            if (!$title) json(['error' => 'Title is required'], 422);
            $listId   = isset($b['list_id'])   ? intval_safe($b['list_id'])   : null;
            $dueDate  = str($b['due_date']  ?? '');
            $isMyDay  = isset($b['is_my_day'])  ? (int)(bool)$b['is_my_day']  : 0;
            $isStarred = isset($b['is_starred']) ? (int)(bool)$b['is_starred'] : 0;

            // Verify list belongs to user
            if ($listId) {
                $list = dbRow('SELECT id FROM lists WHERE id = ? AND user_id = ?', [$listId, $uid]);
                if (!$list) $listId = null;
            }
            if (!$listId) {
                $def = dbRow('SELECT id FROM lists WHERE user_id = ? AND is_default = 1', [$uid]);
                $listId = $def ? (int)$def['id'] : null;
            }

            $id = dbExecute(
                'INSERT INTO tasks (user_id, list_id, title, due_date, is_my_day, my_day_date, is_starred)
                 VALUES (?, ?, ?, ?, ?, ?, ?)',
                [$uid, $listId, $title, $dueDate ?: null, $isMyDay, $isMyDay ? date('Y-m-d') : null, $isStarred]
            );
            json(['task' => dbRow('SELECT * FROM tasks WHERE id = ?', [$id])], 201);
        })(),

        'PUT' => (function () use ($uid, $id) {
            if (!$id) json(['error' => 'Task ID required'], 422);
            $task = dbRow('SELECT * FROM tasks WHERE id = ? AND user_id = ?', [$id, $uid]);
            if (!$task) json(['error' => 'Not found'], 404);
            $b = body();

            $fields = [];
            $params = [];

            $updatable = ['title', 'notes', 'due_date', 'reminder', 'list_id'];
            foreach ($updatable as $col) {
                if (array_key_exists($col, $b)) {
                    $fields[] = "$col = ?";
                    $params[] = ($b[$col] === '' || $b[$col] === null) ? null : $b[$col];
                }
            }

            $boolCols = ['is_starred', 'is_completed', 'is_my_day'];
            foreach ($boolCols as $col) {
                if (array_key_exists($col, $b)) {
                    $fields[] = "$col = ?";
                    $params[] = (int)(bool)$b[$col];
                    if ($col === 'is_my_day') {
                        $fields[] = 'my_day_date = ?';
                        $params[] = $b[$col] ? date('Y-m-d') : null;
                    }
                }
            }

            if ($fields) {
                $fields[] = "updated_at = datetime('now')";
                $params[] = $id;
                $params[] = $uid;
                dbExecute('UPDATE tasks SET ' . implode(', ', $fields) . ' WHERE id = ? AND user_id = ?', $params);
            }
            json(['task' => dbRow('SELECT * FROM tasks WHERE id = ?', [$id])]);
        })(),

        'DELETE' => (function () use ($uid, $id) {
            if (!$id) json(['error' => 'Task ID required'], 422);
            $task = dbRow('SELECT id FROM tasks WHERE id = ? AND user_id = ?', [$id, $uid]);
            if (!$task) json(['error' => 'Not found'], 404);
            dbExecute('DELETE FROM tasks WHERE id = ? AND user_id = ?', [$id, $uid]);
            json(['ok' => true]);
        })(),

        default => json(['error' => 'Method not allowed'], 405),
    };
}

// ── SUBTASKS ───────────────────────────────────────────────────────────────

function handleSubtasks(string $method): never {
    $uid    = requireAuth();
    $id     = isset($_GET['id'])      ? intval_safe($_GET['id'])      : null;
    $taskId = isset($_GET['task_id']) ? intval_safe($_GET['task_id']) : null;

    match ($method) {
        'GET' => (function () use ($uid, $taskId) {
            if (!$taskId) json(['error' => 'task_id required'], 422);
            // Verify task ownership
            $task = dbRow('SELECT id FROM tasks WHERE id = ? AND user_id = ?', [$taskId, $uid]);
            if (!$task) json(['error' => 'Not found'], 404);
            $subs = dbRows('SELECT * FROM subtasks WHERE task_id = ? ORDER BY sort_order ASC, id ASC', [$taskId]);
            json(['subtasks' => $subs]);
        })(),

        'POST' => (function () use ($uid, $taskId) {
            $b      = body();
            $tId    = $taskId ?? (isset($b['task_id']) ? intval_safe($b['task_id']) : 0);
            $title  = str($b['title'] ?? '');
            if (!$tId)   json(['error' => 'task_id required'], 422);
            if (!$title) json(['error' => 'Title required'], 422);
            $task = dbRow('SELECT id FROM tasks WHERE id = ? AND user_id = ?', [$tId, $uid]);
            if (!$task) json(['error' => 'Not found'], 404);
            $id = dbExecute('INSERT INTO subtasks (task_id, title) VALUES (?, ?)', [$tId, $title]);
            json(['subtask' => dbRow('SELECT * FROM subtasks WHERE id = ?', [$id])], 201);
        })(),

        'PUT' => (function () use ($uid, $id) {
            if (!$id) json(['error' => 'Subtask ID required'], 422);
            $sub = dbRow('SELECT s.* FROM subtasks s JOIN tasks t ON t.id = s.task_id WHERE s.id = ? AND t.user_id = ?', [$id, $uid]);
            if (!$sub) json(['error' => 'Not found'], 404);
            $b = body();
            $title = array_key_exists('title', $b) ? str($b['title']) : $sub['title'];
            $done  = array_key_exists('is_completed', $b) ? (int)(bool)$b['is_completed'] : (int)$sub['is_completed'];
            dbExecute('UPDATE subtasks SET title = ?, is_completed = ? WHERE id = ?', [$title, $done, $id]);
            json(['subtask' => dbRow('SELECT * FROM subtasks WHERE id = ?', [$id])]);
        })(),

        'DELETE' => (function () use ($uid, $id) {
            if (!$id) json(['error' => 'Subtask ID required'], 422);
            $sub = dbRow('SELECT s.id FROM subtasks s JOIN tasks t ON t.id = s.task_id WHERE s.id = ? AND t.user_id = ?', [$id, $uid]);
            if (!$sub) json(['error' => 'Not found'], 404);
            dbExecute('DELETE FROM subtasks WHERE id = ?', [$id]);
            json(['ok' => true]);
        })(),

        default => json(['error' => 'Method not allowed'], 405),
    };
}
