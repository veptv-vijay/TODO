# MS To Do Clone – PHP 8.5 / Azure App Services

A fully functional Microsoft To Do clone built with PHP 8.x, SQLite, and vanilla JS.

## Features

- ✅ User registration & login (bcrypt)
- ☑️ Tasks with title, notes, due date, reminder
- ⭐ Important / starred tasks
- ☀️ My Day view
- 📅 Planned view (tasks with due dates)
- 📋 Custom lists (create, rename, delete)
- ➕ Subtasks (steps) per task
- 🔍 Filter views: My Day, Important, Planned, All, by List
- 🗑️ Task & list deletion with confirmation
- 💾 SQLite — zero DB setup required
- 🔒 Session auth, CSRF-safe, prepared statements

## Requirements

- PHP 8.0+ (tested on 8.5)
- `pdo_sqlite` extension enabled
- Azure App Services (Windows) with PHP runtime

## Azure Deployment

### 1. Create App Service
```
az appservice plan create --name myplan --resource-group myRG --sku B1 --is-linux false
az webapp create --name myapp --plan myplan --resource-group myRG --runtime "PHP|8.2"
```

### 2. Enable persistent storage
In Azure Portal → Your App → Configuration → Application settings:
```
WEBSITES_ENABLE_APP_SERVICE_STORAGE = true
```

### 3. Deploy the ZIP
```bash
az webapp deployment source config-zip \
  --name myapp \
  --resource-group myRG \
  --src mstodo.zip
```

### 4. First run
Visit `https://myapp.azurewebsites.net/register` to create your account.
The SQLite database is auto-created at `/home/data/tasks.db` on first request.

## Local Development

```bash
cd mstodo
php -S localhost:8080
```
Visit: http://localhost:8080/register

Requires PHP with `pdo_sqlite` extension.

## API Reference

All endpoints: `POST/GET/PUT/DELETE /api.php?action=<action>`

| Action | Methods | Description |
|--------|---------|-------------|
| `login` | POST | `{email, password}` → session |
| `register` | POST | `{name, email, password}` → session |
| `logout` | POST | Destroy session |
| `me` | GET | Current user info |
| `lists` | GET | All lists with task counts |
| `lists` | POST | `{name, icon?, color?}` Create list |
| `lists` | PUT `?id=X` | `{name?, icon?, color?}` Update |
| `lists` | DELETE `?id=X` | Delete list |
| `tasks` | GET `?filter=all\|my_day\|important\|planned\|list&list_id=X` | Get tasks |
| `tasks` | POST | `{title, list_id?, due_date?, is_my_day?, is_starred?}` |
| `tasks` | PUT `?id=X` | Update any task fields |
| `tasks` | DELETE `?id=X` | Delete task |
| `subtasks` | GET `?task_id=X` | Get subtasks |
| `subtasks` | POST | `{task_id, title}` |
| `subtasks` | PUT `?id=X` | `{title?, is_completed?}` |
| `subtasks` | DELETE `?id=X` | Delete subtask |

## File Structure

```
mstodo/
├── index.php           Main router
├── api.php             REST API
├── config.php          DB path & constants
├── web.config          Azure IIS rewrite rules
├── .user.ini           PHP settings
├── includes/
│   ├── db.php          PDO SQLite + helpers
│   ├── auth.php        Login/register/session
│   └── helpers.php     json(), requireAuth(), body(), h()
├── views/
│   ├── login.php
│   ├── register.php
│   └── app.php         SPA shell
├── assets/
│   ├── css/app.css     MS To Do-style layout
│   ├── css/auth.css    Auth pages
│   └── js/app.js       Full SPA logic
└── data/
    └── .gitkeep        SQLite DB created here
```
