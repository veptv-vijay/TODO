<?php
declare(strict_types=1);

require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/includes/helpers.php';

$path = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
$path = rtrim($path, '/') ?: '/';

// Strip subdir if deployed in subdirectory
$base = rtrim(dirname($_SERVER['SCRIPT_NAME']), '/');
if ($base && str_starts_with($path, $base)) {
    $path = substr($path, strlen($base)) ?: '/';
}

match (true) {
    str_starts_with($path, '/register') => (function () {
        if (isLoggedIn()) { header('Location: /'); exit; }
        require __DIR__ . '/views/register.php';
    })(),

    str_starts_with($path, '/logout') => (function () {
        doLogout();
        header('Location: /login');
        exit;
    })(),

    str_starts_with($path, '/login') => (function () {
        if (isLoggedIn()) { header('Location: /'); exit; }
        require __DIR__ . '/views/login.php';
    })(),

    default => (function () {
        if (!isLoggedIn()) { header('Location: /login'); exit; }
        require __DIR__ . '/views/app.php';
    })(),
};
