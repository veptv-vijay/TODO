'use strict';

// ── STATE ──────────────────────────────────────────────────────────────────
const S = {
  user:          null,
  lists:         [],
  tasks:         [],
  subtasks:      [],
  filter:        'all',    // my_day | important | planned | all | list
  listId:        null,
  taskId:        null,
  completedOpen: false,
  addMyDay:      false,
  addStar:       false,
  addDue:        null,
  modalCb:       null,
};

// ── API ────────────────────────────────────────────────────────────────────
const API = {
  async req(method, action, body, params = {}) {
    const qs = new URLSearchParams({ action, ...params }).toString();
    const opts = { method, headers: { 'Content-Type': 'application/json' } };
    if (body) opts.body = JSON.stringify(body);
    const r = await fetch('/api.php?' + qs, opts);
    const d = await r.json();
    if (!r.ok) throw new Error(d.error || 'Request failed');
    return d;
  },
  get:  (action, params)    => API.req('GET',    action, null, params),
  post: (action, body)      => API.req('POST',   action, body),
  put:  (action, body, params) => API.req('PUT', action, body, params),
  del:  (action, params)    => API.req('DELETE', action, null, params),
};

// ── TOAST ──────────────────────────────────────────────────────────────────
let toastTimer = null;
function toast(msg, duration = 2500) {
  const el = document.getElementById('toast');
  el.textContent = msg;
  el.classList.remove('hidden');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => el.classList.add('hidden'), duration);
}

// ── HELPERS ────────────────────────────────────────────────────────────────
function esc(s) {
  const d = document.createElement('div');
  d.textContent = s;
  return d.innerHTML;
}

function formatDate(dateStr) {
  if (!dateStr) return '';
  const d   = new Date(dateStr + 'T00:00:00');
  const now = new Date();
  now.setHours(0,0,0,0);
  const diff = Math.round((d - now) / 86400000);
  if (diff === 0) return 'Today';
  if (diff === 1) return 'Tomorrow';
  if (diff === -1) return 'Yesterday';
  return d.toLocaleDateString(undefined, { month: 'short', day: 'numeric' });
}

function isOverdue(dateStr) {
  if (!dateStr) return false;
  const d   = new Date(dateStr + 'T00:00:00');
  const now = new Date();
  now.setHours(0,0,0,0);
  return d < now;
}

// ── INIT ───────────────────────────────────────────────────────────────────
async function init() {
  try {
    const d = await API.get('me');
    S.user = d.user;
    document.getElementById('userInitial').textContent = S.user.name[0].toUpperCase();
    document.getElementById('userMenuName').textContent  = S.user.name;
    document.getElementById('userMenuEmail').textContent = S.user.email;
  } catch (e) {
    window.location.href = '/login';
    return;
  }

  bindEvents();
  await loadLists();
  await loadTasks();
}

// ── LOAD DATA ──────────────────────────────────────────────────────────────
async function loadLists() {
  const d = await API.get('lists');
  S.lists = d.lists;
  renderSidebar();
}

async function loadTasks() {
  const params = { filter: S.filter };
  if (S.filter === 'list' && S.listId) params.list_id = S.listId;
  const d = await API.get('tasks', params);
  S.tasks = d.tasks;
  renderTaskList();
  updateBadges();
}

async function loadSubtasks(taskId) {
  const d = await API.get('subtasks', { task_id: taskId });
  S.subtasks = d.subtasks;
}

// ── RENDER SIDEBAR ─────────────────────────────────────────────────────────
function renderSidebar() {
  // Highlight active nav
  document.querySelectorAll('.nav-item').forEach(btn => {
    const f = btn.dataset.filter;
    btn.classList.toggle('active', S.filter === f && S.filter !== 'list');
  });

  // Lists
  const el = document.getElementById('listNav');
  el.innerHTML = S.lists.map(list => `
    <button class="list-item${S.filter === 'list' && S.listId === list.id ? ' active' : ''}"
            data-list-id="${list.id}">
      <span class="list-item-icon">${esc(list.icon)}</span>
      <span class="list-item-name">${esc(list.name)}</span>
      ${list.task_count > 0 ? `<span class="list-item-count">${list.task_count}</span>` : ''}
      <button class="list-item-more" data-list-id="${list.id}" title="More options">•••</button>
    </button>
  `).join('');

  el.querySelectorAll('.list-item').forEach(btn => {
    btn.addEventListener('click', (e) => {
      if (e.target.classList.contains('list-item-more')) return;
      const id = parseInt(btn.dataset.listId);
      S.filter = 'list';
      S.listId = id;
      renderSidebar();
      loadTasks();
      updateMainHeader();
    });
  });

  el.querySelectorAll('.list-item-more').forEach(btn => {
    btn.addEventListener('click', e => {
      e.stopPropagation();
      showListCtxMenu(parseInt(btn.dataset.listId), e.clientX, e.clientY);
    });
  });
}

function updateMainHeader() {
  let title = 'Tasks';
  if (S.filter === 'my_day')    title = 'My Day';
  if (S.filter === 'important') title = 'Important';
  if (S.filter === 'planned')   title = 'Planned';
  if (S.filter === 'all')       title = 'Tasks';
  if (S.filter === 'list') {
    const list = S.lists.find(l => l.id === S.listId);
    title = list ? list.name : 'List';
  }
  document.getElementById('mainTitle').textContent = title;
}

function updateBadges() {
  const today = new Date().toISOString().slice(0,10);
  const counts = {
    my_day:    S.tasks.filter(t => t.is_my_day && !t.is_completed).length,
    important: S.tasks.filter(t => t.is_starred && !t.is_completed).length,
    planned:   S.tasks.filter(t => t.due_date && !t.is_completed).length,
    all:       S.tasks.filter(t => !t.is_completed).length,
  };
  // Reload all tasks for accurate counts only if in sub-filter
  document.querySelectorAll('[data-badge]').forEach(el => {
    const k = el.dataset.badge;
    // We'll just show nothing for now; badges update after full reload
    el.textContent = '';
  });
}

// ── RENDER TASK LIST ───────────────────────────────────────────────────────
function renderTaskList() {
  updateMainHeader();
  const el = document.getElementById('taskList');
  const active    = S.tasks.filter(t => !t.is_completed);
  const completed = S.tasks.filter(t => t.is_completed);

  el.innerHTML = '';

  active.forEach(task => el.appendChild(makeTaskEl(task)));

  if (completed.length > 0) {
    const section = document.createElement('div');
    section.className = 'completed-section';
    section.innerHTML = `
      <div class="completed-header" id="completedHeader">
        <span>${S.completedOpen ? '▾' : '▸'}</span>
        <span>Completed</span>
        <span style="margin-left:.5rem;color:var(--text-muted);font-size:.8rem">${completed.length}</span>
      </div>
      <div class="completed-tasks" id="completedTasks" ${S.completedOpen ? '' : 'style="display:none"'}></div>
    `;
    el.appendChild(section);

    document.getElementById('completedHeader').addEventListener('click', () => {
      S.completedOpen = !S.completedOpen;
      renderTaskList();
    });

    const ct = document.getElementById('completedTasks');
    completed.forEach(task => ct.appendChild(makeTaskEl(task)));
  }
}

function makeTaskEl(task) {
  const div = document.createElement('div');
  div.className = 'task-item' + (S.taskId === task.id ? ' selected' : '');
  div.dataset.taskId = task.id;

  const today = new Date().toISOString().slice(0,10);
  const overdue = task.due_date && task.due_date < today && !task.is_completed;

  div.innerHTML = `
    <div class="task-check${task.is_completed ? ' done' : ''}" data-check="${task.id}">
      ${task.is_completed ? '✓' : ''}
    </div>
    <div class="task-title${task.is_completed ? ' done' : ''}">${esc(task.title)}</div>
    <div class="task-meta">
      ${task.is_my_day && S.filter !== 'my_day' ? '<span>☀️</span>' : ''}
      ${task.due_date ? `<span class="${overdue ? 'overdue' : ''}">${formatDate(task.due_date)}</span>` : ''}
      ${task.list_name && S.filter !== 'list' ? `<span>${esc(task.list_name)}</span>` : ''}
    </div>
    <button class="task-star${task.is_starred ? ' on' : ''}" data-star="${task.id}" title="Important">
      ${task.is_starred ? '⭐' : '☆'}
    </button>
  `;

  div.querySelector('[data-check]').addEventListener('click', e => {
    e.stopPropagation();
    toggleComplete(task);
  });

  div.querySelector('[data-star]').addEventListener('click', e => {
    e.stopPropagation();
    toggleStar(task);
  });

  div.addEventListener('click', () => openDetail(task.id));

  return div;
}

// ── TASK ACTIONS ───────────────────────────────────────────────────────────
async function toggleComplete(task) {
  try {
    await API.put('tasks', { is_completed: !task.is_completed }, { id: task.id });
    await loadTasks();
    if (S.taskId === task.id) {
      const updated = S.tasks.find(t => t.id === task.id);
      if (updated) renderDetail(updated);
      else closeDetail();
    }
  } catch(e) { toast('Error: ' + e.message); }
}

async function toggleStar(task) {
  try {
    await API.put('tasks', { is_starred: !task.is_starred }, { id: task.id });
    await loadTasks();
    if (S.taskId === task.id) {
      const updated = S.tasks.find(t => t.id === task.id);
      if (updated) renderDetail(updated);
    }
  } catch(e) { toast('Error: ' + e.message); }
}

async function createTask() {
  const input = document.getElementById('newTaskInput');
  const title = input.value.trim();
  if (!title) return;

  const body = {
    title,
    is_my_day:  S.addMyDay ? 1 : 0,
    is_starred: S.addStar  ? 1 : 0,
    due_date:   S.addDue   || '',
  };

  if (S.filter === 'list' && S.listId) body.list_id = S.listId;

  try {
    await API.post('tasks', body);
    input.value = '';
    S.addMyDay = false;
    S.addStar  = false;
    S.addDue   = null;
    document.getElementById('addMyDayBtn').classList.remove('active');
    document.getElementById('addStarBtn').classList.remove('active');
    document.getElementById('addDueInput').classList.add('hidden');
    document.getElementById('addDueInput').value = '';
    await loadTasks();
    await loadLists();
    toast('Task added');
  } catch(e) { toast('Error: ' + e.message); }
}

async function deleteTask(taskId) {
  if (!confirm('Delete this task?')) return;
  try {
    await API.del('tasks', { id: taskId });
    closeDetail();
    await loadTasks();
    await loadLists();
    toast('Task deleted');
  } catch(e) { toast('Error: ' + e.message); }
}

// ── DETAIL PANEL ───────────────────────────────────────────────────────────
async function openDetail(taskId) {
  S.taskId = taskId;
  const task = S.tasks.find(t => t.id === taskId);
  if (!task) return;

  await loadSubtasks(taskId);
  renderDetail(task);

  document.getElementById('detail').classList.remove('hidden');
  document.querySelectorAll('.task-item').forEach(el => {
    el.classList.toggle('selected', parseInt(el.dataset.taskId) === taskId);
  });
}

function closeDetail() {
  S.taskId = null;
  document.getElementById('detail').classList.add('hidden');
  document.querySelectorAll('.task-item').forEach(el => el.classList.remove('selected'));
}

function renderDetail(task) {
  const today = new Date().toISOString().slice(0,10);
  const overdue = task.due_date && task.due_date < today && !task.is_completed;

  const listsOpts = S.lists.map(l =>
    `<option value="${l.id}" ${l.id === task.list_id ? 'selected' : ''}>${esc(l.name)}</option>`
  ).join('');

  document.getElementById('detailContent').innerHTML = `
    <div class="detail-task-title">
      <div class="task-check${task.is_completed ? ' done' : ''}" id="detailCheck">
        ${task.is_completed ? '✓' : ''}
      </div>
      <textarea id="detailTitle" rows="2">${esc(task.title)}</textarea>
      <button class="task-star${task.is_starred ? ' on' : ''}" id="detailStar" title="Important">
        ${task.is_starred ? '⭐' : '☆'}
      </button>
    </div>

    <!-- Subtasks -->
    <div class="detail-section">
      <div class="subtask-list" id="subtaskList"></div>
      <div class="add-subtask-row">
        <input type="text" class="add-subtask-input" id="addSubtaskInput" placeholder="+ Add step">
      </div>
    </div>

    <!-- Options -->
    <div class="detail-section">
      <div class="detail-section-row" id="myDayRow">
        <span class="section-icon">☀️</span>
        <span class="section-label">Add to My Day</span>
        <span class="section-value">${task.is_my_day ? 'Added ✓' : ''}</span>
      </div>
      <div class="detail-section-row ${overdue ? 'overdue' : ''}" id="dueRow">
        <span class="section-icon">📅</span>
        <span class="section-label">Due date</span>
        <span class="section-value" id="dueValue">
          ${task.due_date ? formatDate(task.due_date) : 'Add due date'}
        </span>
        <input type="date" id="dueInput" class="hidden" value="${task.due_date || ''}">
      </div>
      <div class="detail-section-row" id="reminderRow">
        <span class="section-icon">🔔</span>
        <span class="section-label">Remind me</span>
        <span class="section-value">${task.reminder ? new Date(task.reminder).toLocaleString() : 'Add reminder'}</span>
        <input type="datetime-local" id="reminderInput" class="hidden" value="${task.reminder || ''}">
      </div>
      <div class="detail-section-row">
        <span class="section-icon">📋</span>
        <span class="section-label">List</span>
        <select class="detail-list-select" id="listSelect">${listsOpts}</select>
      </div>
    </div>

    <!-- Notes -->
    <div class="detail-notes">
      <textarea id="detailNotes" placeholder="Add note…">${esc(task.notes || '')}</textarea>
    </div>

    <!-- Created -->
    <p style="font-size:.75rem;color:var(--text-muted);text-align:center;margin:.5rem 0">
      Created ${new Date(task.created_at).toLocaleDateString()}
    </p>

    <!-- Delete -->
    <div class="detail-delete">
      <button class="btn-delete" id="deleteTaskBtn">🗑 Delete task</button>
    </div>
  `;

  renderSubtasks();
  bindDetailEvents(task);
}

function renderSubtasks() {
  const el = document.getElementById('subtaskList');
  if (!el) return;
  el.innerHTML = S.subtasks.map(sub => `
    <div class="subtask-item" data-sub-id="${sub.id}">
      <div class="subtask-check${sub.is_completed ? ' done' : ''}" data-sub-check="${sub.id}">
        ${sub.is_completed ? '✓' : ''}
      </div>
      <input class="subtask-title${sub.is_completed ? ' done' : ''}"
             value="${esc(sub.title)}"
             data-sub-input="${sub.id}">
      <button class="subtask-del" data-sub-del="${sub.id}" title="Delete">✕</button>
    </div>
  `).join('');

  el.querySelectorAll('[data-sub-check]').forEach(btn => {
    const id = parseInt(btn.dataset.subCheck);
    const sub = S.subtasks.find(s => s.id === id);
    btn.addEventListener('click', () => toggleSubtask(sub));
  });

  el.querySelectorAll('[data-sub-input]').forEach(input => {
    const id = parseInt(input.dataset.subInput);
    input.addEventListener('change', async () => {
      const title = input.value.trim();
      if (!title) return;
      try {
        await API.put('subtasks', { title }, { id });
        await loadSubtasks(S.taskId);
        renderSubtasks();
      } catch(e) { toast('Error: ' + e.message); }
    });
  });

  el.querySelectorAll('[data-sub-del]').forEach(btn => {
    const id = parseInt(btn.dataset.subDel);
    btn.addEventListener('click', async () => {
      try {
        await API.del('subtasks', { id });
        await loadSubtasks(S.taskId);
        renderSubtasks();
      } catch(e) { toast('Error: ' + e.message); }
    });
  });
}

function bindDetailEvents(task) {
  // Close
  document.getElementById('closeDetail').addEventListener('click', closeDetail);

  // Check
  document.getElementById('detailCheck').addEventListener('click', () => toggleComplete(task));

  // Star
  document.getElementById('detailStar').addEventListener('click', () => toggleStar(task));

  // Title (save on blur/enter)
  const titleEl = document.getElementById('detailTitle');
  const saveTitle = async () => {
    const title = titleEl.value.trim();
    if (!title || title === task.title) return;
    try {
      await API.put('tasks', { title }, { id: task.id });
      task.title = title;
      await loadTasks();
    } catch(e) { toast('Error: ' + e.message); }
  };
  titleEl.addEventListener('blur', saveTitle);
  titleEl.addEventListener('keydown', e => { if (e.key === 'Enter') { e.preventDefault(); titleEl.blur(); } });

  // My Day
  document.getElementById('myDayRow').addEventListener('click', async () => {
    try {
      await API.put('tasks', { is_my_day: task.is_my_day ? 0 : 1 }, { id: task.id });
      await loadTasks();
      const updated = S.tasks.find(t => t.id === task.id);
      if (updated) renderDetail(updated);
    } catch(e) { toast('Error: ' + e.message); }
  });

  // Due date
  const dueRow   = document.getElementById('dueRow');
  const dueValue = document.getElementById('dueValue');
  const dueInput = document.getElementById('dueInput');

  dueRow.addEventListener('click', (e) => {
    if (e.target === dueInput) return;
    dueInput.classList.toggle('hidden');
    if (!dueInput.classList.contains('hidden')) dueInput.focus();
  });

  dueInput.addEventListener('change', async () => {
    try {
      await API.put('tasks', { due_date: dueInput.value || null }, { id: task.id });
      task.due_date = dueInput.value;
      dueValue.textContent = dueInput.value ? formatDate(dueInput.value) : 'Add due date';
      dueInput.classList.add('hidden');
      await loadTasks();
    } catch(e) { toast('Error: ' + e.message); }
  });

  // Reminder
  const reminderRow   = document.getElementById('reminderRow');
  const reminderInput = document.getElementById('reminderInput');
  reminderRow.addEventListener('click', (e) => {
    if (e.target === reminderInput) return;
    reminderInput.classList.toggle('hidden');
    if (!reminderInput.classList.contains('hidden')) reminderInput.focus();
  });
  reminderInput.addEventListener('change', async () => {
    try {
      await API.put('tasks', { reminder: reminderInput.value || null }, { id: task.id });
      reminderInput.classList.add('hidden');
      await loadTasks();
      const updated = S.tasks.find(t => t.id === task.id);
      if (updated) renderDetail(updated);
    } catch(e) { toast('Error: ' + e.message); }
  });

  // List
  document.getElementById('listSelect').addEventListener('change', async (e) => {
    const listId = parseInt(e.target.value);
    try {
      await API.put('tasks', { list_id: listId }, { id: task.id });
      await loadTasks();
      await loadLists();
    } catch(e) { toast('Error: ' + e.message); }
  });

  // Notes
  const notesEl = document.getElementById('detailNotes');
  let notesTimer = null;
  notesEl.addEventListener('input', () => {
    clearTimeout(notesTimer);
    notesTimer = setTimeout(async () => {
      try {
        await API.put('tasks', { notes: notesEl.value }, { id: task.id });
      } catch(e) { toast('Error saving notes'); }
    }, 800);
  });

  // Add subtask
  const addSubInput = document.getElementById('addSubtaskInput');
  addSubInput.addEventListener('keydown', async (e) => {
    if (e.key !== 'Enter') return;
    const title = addSubInput.value.trim();
    if (!title) return;
    try {
      await API.post('subtasks', { task_id: task.id, title });
      addSubInput.value = '';
      await loadSubtasks(task.id);
      renderSubtasks();
    } catch(e) { toast('Error: ' + e.message); }
  });

  // Delete task
  document.getElementById('deleteTaskBtn').addEventListener('click', () => deleteTask(task.id));
}

// ── SUBTASK TOGGLE ─────────────────────────────────────────────────────────
async function toggleSubtask(sub) {
  try {
    await API.put('subtasks', { is_completed: !sub.is_completed }, { id: sub.id });
    await loadSubtasks(S.taskId);
    renderSubtasks();
  } catch(e) { toast('Error: ' + e.message); }
}

// ── LIST CONTEXT MENU ──────────────────────────────────────────────────────
function showListCtxMenu(listId, x, y) {
  removeCtxMenu();
  const list = S.lists.find(l => l.id === listId);
  if (!list) return;

  const menu = document.createElement('div');
  menu.className = 'ctx-menu';
  menu.id = 'ctxMenu';
  menu.style.left = x + 'px';
  menu.style.top  = y + 'px';
  menu.innerHTML = `
    <button class="ctx-item" id="ctxRename">✏️ Rename list</button>
    ${!list.is_default ? `<button class="ctx-item danger" id="ctxDelete">🗑 Delete list</button>` : ''}
  `;
  document.body.appendChild(menu);

  document.getElementById('ctxRename').addEventListener('click', () => {
    removeCtxMenu();
    openModal('Rename list', list.name, async (name) => {
      if (!name) return;
      try {
        await API.put('lists', { name }, { id: listId });
        await loadLists();
        if (S.filter === 'list' && S.listId === listId) updateMainHeader();
        toast('List renamed');
      } catch(e) { toast('Error: ' + e.message); }
    });
  });

  const delBtn = document.getElementById('ctxDelete');
  if (delBtn) {
    delBtn.addEventListener('click', async () => {
      removeCtxMenu();
      if (!confirm(`Delete list "${list.name}" and all its tasks?`)) return;
      try {
        await API.del('lists', { id: listId });
        if (S.filter === 'list' && S.listId === listId) {
          S.filter = 'all';
          S.listId = null;
        }
        await loadLists();
        await loadTasks();
        closeDetail();
        toast('List deleted');
      } catch(e) { toast('Error: ' + e.message); }
    });
  }

  setTimeout(() => {
    document.addEventListener('click', removeCtxMenu, { once: true });
  }, 0);
}

function removeCtxMenu() {
  const m = document.getElementById('ctxMenu');
  if (m) m.remove();
}

// ── MODAL ──────────────────────────────────────────────────────────────────
function openModal(title, value, cb) {
  S.modalCb = cb;
  document.getElementById('modalTitle').textContent   = title;
  document.getElementById('modalInput').value         = value;
  document.getElementById('modalOverlay').classList.remove('hidden');
  document.getElementById('modalInput').focus();
  document.getElementById('modalInput').select();
}

function closeModal() {
  document.getElementById('modalOverlay').classList.add('hidden');
  S.modalCb = null;
}

function confirmModal() {
  const val = document.getElementById('modalInput').value.trim();
  if (!val) { document.getElementById('modalInput').focus(); return; }
  if (S.modalCb) S.modalCb(val);
  closeModal();
}

// ── BIND TOP-LEVEL EVENTS ──────────────────────────────────────────────────
function bindEvents() {
  // User menu toggle
  document.getElementById('userMenuBtn').addEventListener('click', () => {
    document.getElementById('userMenu').classList.toggle('hidden');
  });
  document.addEventListener('click', (e) => {
    if (!document.getElementById('sidebar').contains(e.target)) {
      document.getElementById('userMenu').classList.add('hidden');
    }
  });

  // Nav filters
  document.querySelectorAll('.nav-item').forEach(btn => {
    btn.addEventListener('click', () => {
      S.filter = btn.dataset.filter;
      S.listId = null;
      closeDetail();
      renderSidebar();
      loadTasks();
    });
  });

  // Add task trigger
  document.getElementById('addTaskBtn').addEventListener('click', () => {
    document.getElementById('addTaskBtn').classList.add('hidden');
    document.getElementById('addTaskForm').classList.remove('hidden');
    document.getElementById('newTaskInput').focus();
  });

  document.getElementById('cancelAddTask').addEventListener('click', () => {
    document.getElementById('addTaskForm').classList.add('hidden');
    document.getElementById('addTaskBtn').classList.remove('hidden');
    document.getElementById('newTaskInput').value = '';
    S.addMyDay = false; S.addStar = false; S.addDue = null;
    document.getElementById('addMyDayBtn').classList.remove('active');
    document.getElementById('addStarBtn').classList.remove('active');
    document.getElementById('addDueInput').classList.add('hidden');
  });

  document.getElementById('submitAddTask').addEventListener('click', createTask);

  document.getElementById('newTaskInput').addEventListener('keydown', e => {
    if (e.key === 'Enter') createTask();
    if (e.key === 'Escape') document.getElementById('cancelAddTask').click();
  });

  // Add task options
  document.getElementById('addMyDayBtn').addEventListener('click', () => {
    S.addMyDay = !S.addMyDay;
    document.getElementById('addMyDayBtn').classList.toggle('active', S.addMyDay);
  });

  document.getElementById('addStarBtn').addEventListener('click', () => {
    S.addStar = !S.addStar;
    document.getElementById('addStarBtn').classList.toggle('active', S.addStar);
  });

  document.getElementById('addDueBtn').addEventListener('click', () => {
    const inp = document.getElementById('addDueInput');
    inp.classList.toggle('hidden');
    if (!inp.classList.contains('hidden')) inp.focus();
  });

  document.getElementById('addDueInput').addEventListener('change', e => {
    S.addDue = e.target.value;
    document.getElementById('addDueBtn').classList.toggle('active', !!S.addDue);
  });

  // Toggle completed section
  document.getElementById('toggleCompleted').addEventListener('click', () => {
    S.completedOpen = !S.completedOpen;
    renderTaskList();
  });

  // Add list
  document.getElementById('addListBtn').addEventListener('click', () => {
    openModal('New list', '', async (name) => {
      try {
        const d = await API.post('lists', { name });
        S.filter = 'list';
        S.listId = d.list.id;
        await loadLists();
        await loadTasks();
        toast('List created');
      } catch(e) { toast('Error: ' + e.message); }
    });
  });

  // Modal events
  document.getElementById('modalCancel').addEventListener('click',  closeModal);
  document.getElementById('modalConfirm').addEventListener('click', confirmModal);
  document.getElementById('modalInput').addEventListener('keydown', e => {
    if (e.key === 'Enter')  confirmModal();
    if (e.key === 'Escape') closeModal();
  });
  document.getElementById('modalOverlay').addEventListener('click', e => {
    if (e.target === document.getElementById('modalOverlay')) closeModal();
  });

  // Global Escape
  document.addEventListener('keydown', e => {
    if (e.key === 'Escape') {
      if (!document.getElementById('modalOverlay').classList.contains('hidden')) {
        closeModal(); return;
      }
      if (S.taskId) { closeDetail(); return; }
    }
  });
}

// ── BOOT ───────────────────────────────────────────────────────────────────
document.addEventListener('DOMContentLoaded', init);
