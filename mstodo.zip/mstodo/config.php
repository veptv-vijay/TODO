<?php
declare(strict_types=1);

// Azure App Services detection
if (getenv('WEBSITE_SITE_NAME')) {
    define('DB_PATH', '/home/data/tasks.db');
} else {
    define('DB_PATH', __DIR__ . '/data/tasks.db');
}

define('APP_NAME', 'MS To Do Clone');
define('SESSION_NAME', 'MSTODO_SESSION');
