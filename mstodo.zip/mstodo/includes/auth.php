<?php
declare(strict_types=1);

require_once __DIR__ . '/db.php';

function startSession(): void {
    if (session_status() === PHP_SESSION_NONE) {
        session_name(SESSION_NAME);
        session_set_cookie_params([
            'lifetime' => 86400 * 30,
            'path'     => '/',
            'secure'   => isset($_SERVER['HTTPS']),
            'httponly' => true,
            'samesite' => 'Lax',
        ]);
        session_start();
    }
}

function isLoggedIn(): bool {
    startSession();
    return isset($_SESSION['user_id']);
}

function sessionUserId(): int {
    return (int) ($_SESSION['user_id'] ?? 0);
}

function getCurrentUser(): array|false {
    if (!isLoggedIn()) return false;
    return dbRow('SELECT id, name, email, theme, created_at FROM users WHERE id = ?', [sessionUserId()]);
}

function login(string $email, string $password): array|false {
    $user = dbRow('SELECT * FROM users WHERE email = ?', [trim($email)]);
    if (!$user || !password_verify($password, $user['password'])) {
        return false;
    }
    startSession();
    session_regenerate_id(true);
    $_SESSION['user_id'] = $user['id'];
    return $user;
}

function register(string $name, string $email, string $password): array|string {
    $email = trim($email);
    $name  = trim($name);

    if (strlen($name) < 2)     return 'Name must be at least 2 characters.';
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) return 'Invalid email address.';
    if (strlen($password) < 6) return 'Password must be at least 6 characters.';

    if (dbRow('SELECT id FROM users WHERE email = ?', [$email])) {
        return 'An account with that email already exists.';
    }

    $hash = password_hash($password, PASSWORD_BCRYPT, ['cost' => 12]);
    $id   = dbExecute(
        'INSERT INTO users (name, email, password) VALUES (?, ?, ?)',
        [$name, $email, $hash]
    );

    // Create default "Tasks" list
    dbExecute(
        'INSERT INTO lists (user_id, name, icon, color, is_default) VALUES (?, ?, ?, ?, 1)',
        [$id, 'Tasks', '☑️', '#2564CF']
    );

    $user = dbRow('SELECT * FROM users WHERE id = ?', [$id]);
    startSession();
    session_regenerate_id(true);
    $_SESSION['user_id'] = $id;
    return $user;
}

function doLogout(): void {
    startSession();
    $_SESSION = [];
    session_destroy();
}
