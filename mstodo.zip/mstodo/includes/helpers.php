<?php
declare(strict_types=1);

function json(mixed $data, int $status = 200): never {
    http_response_code($status);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

function requireAuth(): int {
    if (!isLoggedIn()) {
        json(['error' => 'Unauthorized'], 401);
    }
    return sessionUserId();
}

function body(): array {
    $raw = file_get_contents('php://input');
    if (!$raw) return [];
    $data = json_decode($raw, true);
    return is_array($data) ? $data : [];
}

function h(mixed $v): string {
    return htmlspecialchars((string) $v, ENT_QUOTES | ENT_HTML5, 'UTF-8');
}

function str(mixed $v): string {
    return trim((string) $v);
}

function intval_safe(mixed $v): int {
    return (int) $v;
}
