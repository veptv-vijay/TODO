<?php
declare(strict_types=1);

require_once __DIR__ . '/../config.php';

function getDB(): PDO {
    static $pdo = null;
    if ($pdo === null) {
        $dir = dirname(DB_PATH);
        if (!is_dir($dir)) {
            mkdir($dir, 0755, true);
        }
        $pdo = new PDO('sqlite:' . DB_PATH, null, null, [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        ]);
        $pdo->exec('PRAGMA journal_mode=WAL');
        $pdo->exec('PRAGMA foreign_keys=ON');
        migrateDB($pdo);
    }
    return $pdo;
}

function migrateDB(PDO $pdo): void {
    $pdo->exec("
        CREATE TABLE IF NOT EXISTS users (
            id         INTEGER PRIMARY KEY AUTOINCREMENT,
            name       TEXT NOT NULL,
            email      TEXT NOT NULL UNIQUE COLLATE NOCASE,
            password   TEXT NOT NULL,
            theme      TEXT NOT NULL DEFAULT 'blue',
            created_at TEXT NOT NULL DEFAULT (datetime('now'))
        );

        CREATE TABLE IF NOT EXISTS lists (
            id         INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id    INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
            name       TEXT NOT NULL,
            icon       TEXT NOT NULL DEFAULT '📋',
            color      TEXT NOT NULL DEFAULT '#2564CF',
            is_default INTEGER NOT NULL DEFAULT 0,
            sort_order INTEGER NOT NULL DEFAULT 0,
            created_at TEXT NOT NULL DEFAULT (datetime('now'))
        );

        CREATE TABLE IF NOT EXISTS tasks (
            id           INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id      INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
            list_id      INTEGER REFERENCES lists(id) ON DELETE SET NULL,
            title        TEXT NOT NULL,
            notes        TEXT,
            due_date     TEXT,
            reminder     TEXT,
            is_starred   INTEGER NOT NULL DEFAULT 0,
            is_completed INTEGER NOT NULL DEFAULT 0,
            is_my_day    INTEGER NOT NULL DEFAULT 0,
            my_day_date  TEXT,
            sort_order   INTEGER NOT NULL DEFAULT 0,
            created_at   TEXT NOT NULL DEFAULT (datetime('now')),
            updated_at   TEXT NOT NULL DEFAULT (datetime('now'))
        );

        CREATE TABLE IF NOT EXISTS subtasks (
            id           INTEGER PRIMARY KEY AUTOINCREMENT,
            task_id      INTEGER NOT NULL REFERENCES tasks(id) ON DELETE CASCADE,
            title        TEXT NOT NULL,
            is_completed INTEGER NOT NULL DEFAULT 0,
            sort_order   INTEGER NOT NULL DEFAULT 0,
            created_at   TEXT NOT NULL DEFAULT (datetime('now'))
        );

        CREATE INDEX IF NOT EXISTS idx_tasks_user    ON tasks(user_id);
        CREATE INDEX IF NOT EXISTS idx_tasks_list    ON tasks(list_id);
        CREATE INDEX IF NOT EXISTS idx_subtasks_task ON subtasks(task_id);
    ");
}

function dbRow(string $sql, array $params = []): array|false {
    $st = getDB()->prepare($sql);
    $st->execute($params);
    return $st->fetch();
}

function dbRows(string $sql, array $params = []): array {
    $st = getDB()->prepare($sql);
    $st->execute($params);
    return $st->fetchAll();
}

function dbExecute(string $sql, array $params = []): int {
    $db = getDB();
    $st = $db->prepare($sql);
    $st->execute($params);
    return (int) $db->lastInsertId();
}

function dbCount(string $sql, array $params = []): int {
    $st = getDB()->prepare($sql);
    $st->execute($params);
    return (int) $st->fetchColumn();
}
