<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Microsoft To Do</title>
<link rel="stylesheet" href="/assets/css/app.css">
</head>
<body>

<!-- SIDEBAR -->
<aside id="sidebar">
  <div class="sidebar-user">
    <button id="userMenuBtn" class="user-avatar-btn" aria-label="User menu">
      <span id="userInitial">?</span>
    </button>
    <div id="userMenu" class="user-menu hidden">
      <div id="userMenuName" class="user-menu-name"></div>
      <div id="userMenuEmail" class="user-menu-email"></div>
      <hr>
      <a href="/logout" class="user-menu-item">Sign out</a>
    </div>
  </div>

  <nav class="sidebar-nav">
    <button class="nav-item" data-filter="my_day">
      <span class="nav-icon">☀️</span> My Day
      <span class="nav-badge" data-badge="my_day"></span>
    </button>
    <button class="nav-item" data-filter="important">
      <span class="nav-icon">⭐</span> Important
      <span class="nav-badge" data-badge="important"></span>
    </button>
    <button class="nav-item" data-filter="planned">
      <span class="nav-icon">📅</span> Planned
      <span class="nav-badge" data-badge="planned"></span>
    </button>
    <button class="nav-item" data-filter="all">
      <span class="nav-icon">🏠</span> Tasks
      <span class="nav-badge" data-badge="all"></span>
    </button>
  </nav>

  <div class="sidebar-divider"></div>

  <div id="listNav" class="list-nav"></div>

  <button id="addListBtn" class="add-list-btn">
    <span>+</span> New list
  </button>
</aside>

<!-- MAIN PANEL -->
<main id="main">
  <div id="mainHeader" class="main-header">
    <h1 id="mainTitle">Tasks</h1>
    <div class="main-header-actions">
      <button id="toggleCompleted" class="icon-btn" title="Show/hide completed">✓</button>
    </div>
  </div>

  <div id="addTaskRow" class="add-task-row">
    <button id="addTaskBtn" class="add-task-trigger">
      <span class="plus-icon">+</span>
      <span>Add a task</span>
    </button>
    <div id="addTaskForm" class="add-task-form hidden">
      <input id="newTaskInput" type="text" placeholder="Task title" maxlength="255">
      <div class="add-task-options">
        <button id="addMyDayBtn"  class="opt-btn" title="Add to My Day">☀️</button>
        <button id="addStarBtn"   class="opt-btn" title="Mark important">⭐</button>
        <button id="addDueBtn"    class="opt-btn" title="Set due date">📅</button>
        <input  id="addDueInput"  type="date" class="hidden">
        <div class="add-task-actions">
          <button id="cancelAddTask" class="btn-ghost">Cancel</button>
          <button id="submitAddTask" class="btn-add">Add</button>
        </div>
      </div>
    </div>
  </div>

  <div id="taskList" class="task-list"></div>
</main>

<!-- DETAIL PANEL -->
<aside id="detail" class="detail-panel hidden">
  <div class="detail-header">
    <button id="closeDetail" class="icon-btn">✕</button>
  </div>
  <div id="detailContent" class="detail-content"></div>
</aside>

<!-- MODAL (add/rename list) -->
<div id="modalOverlay" class="modal-overlay hidden">
  <div class="modal">
    <h2 id="modalTitle">New list</h2>
    <input id="modalInput" type="text" placeholder="List name" maxlength="100">
    <div class="modal-actions">
      <button id="modalCancel" class="btn-ghost">Cancel</button>
      <button id="modalConfirm" class="btn-primary">Create</button>
    </div>
  </div>
</div>

<!-- TOAST -->
<div id="toast" class="toast hidden"></div>

<script src="/assets/js/app.js"></script>
</body>
</html>
