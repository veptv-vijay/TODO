<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Create Account – MS To Do</title>
<link rel="stylesheet" href="/assets/css/auth.css">
</head>
<body>
<div class="auth-card">
  <div class="auth-logo">
    <svg width="32" height="32" viewBox="0 0 32 32" fill="none">
      <rect width="32" height="32" rx="6" fill="#2564CF"/>
      <path d="M8 16l5 5 11-10" stroke="#fff" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"/>
    </svg>
    <span>Microsoft To Do</span>
  </div>
  <h1>Create account</h1>
  <div id="err" class="alert" style="display:none"></div>
  <div class="form-group">
    <label>Full name</label>
    <input type="text" id="name" placeholder="Your name" autocomplete="name">
  </div>
  <div class="form-group">
    <label>Email</label>
    <input type="email" id="email" placeholder="Enter your email" autocomplete="email">
  </div>
  <div class="form-group">
    <label>Password</label>
    <input type="password" id="password" placeholder="At least 6 characters" autocomplete="new-password">
  </div>
  <button id="btn" class="btn-primary">Create account</button>
  <p class="auth-link">Already have an account? <a href="/login">Sign in</a></p>
</div>
<script>
const btn = document.getElementById('btn');
const err = document.getElementById('err');

async function doRegister() {
  const name     = document.getElementById('name').value.trim();
  const email    = document.getElementById('email').value.trim();
  const password = document.getElementById('password').value;
  if (!name || !email || !password) { showErr('Please fill in all fields.'); return; }
  btn.disabled = true;
  btn.textContent = 'Creating…';
  try {
    const r = await fetch('/api.php?action=register', {
      method: 'POST',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify({ name, email, password })
    });
    const d = await r.json();
    if (!r.ok) { showErr(d.error || 'Registration failed.'); return; }
    window.location.href = '/';
  } catch(e) {
    showErr('Network error. Please try again.');
  } finally {
    btn.disabled = false;
    btn.textContent = 'Create account';
  }
}

function showErr(msg) {
  err.textContent = msg;
  err.style.display = 'block';
}

btn.addEventListener('click', doRegister);
document.addEventListener('keydown', e => { if (e.key === 'Enter') doRegister(); });
</script>
</body>
</html>
