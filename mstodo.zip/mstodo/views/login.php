<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Sign In – MS To Do</title>
<link rel="stylesheet" href="/assets/css/auth.css">
</head>
<body>
<div class="auth-card">
  <div class="auth-logo">
    <svg width="32" height="32" viewBox="0 0 32 32" fill="none">
      <rect width="32" height="32" rx="6" fill="#2564CF"/>
      <path d="M8 16l5 5 11-10" stroke="#fff" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"/>
    </svg>
    <span>Microsoft To Do</span>
  </div>
  <h1>Sign in</h1>
  <div id="err" class="alert" style="display:none"></div>
  <div class="form-group">
    <label>Email</label>
    <input type="email" id="email" placeholder="Enter your email" autocomplete="email">
  </div>
  <div class="form-group">
    <label>Password</label>
    <input type="password" id="password" placeholder="Enter your password" autocomplete="current-password">
  </div>
  <button id="btn" class="btn-primary">Sign in</button>
  <p class="auth-link">Don't have an account? <a href="/register">Create one</a></p>
</div>
<script>
const btn  = document.getElementById('btn');
const err  = document.getElementById('err');

async function doLogin() {
  const email    = document.getElementById('email').value.trim();
  const password = document.getElementById('password').value;
  if (!email || !password) { showErr('Please fill in all fields.'); return; }
  btn.disabled = true;
  btn.textContent = 'Signing in…';
  try {
    const r = await fetch('/api.php?action=login', {
      method: 'POST',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify({ email, password })
    });
    const d = await r.json();
    if (!r.ok) { showErr(d.error || 'Login failed.'); return; }
    window.location.href = '/';
  } catch(e) {
    showErr('Network error. Please try again.');
  } finally {
    btn.disabled = false;
    btn.textContent = 'Sign in';
  }
}

function showErr(msg) {
  err.textContent = msg;
  err.style.display = 'block';
}

btn.addEventListener('click', doLogin);
document.addEventListener('keydown', e => { if (e.key === 'Enter') doLogin(); });
</script>
</body>
</html>
